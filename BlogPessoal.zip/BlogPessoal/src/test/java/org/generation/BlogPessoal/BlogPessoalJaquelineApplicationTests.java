package org.generation.BlogPessoal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogPessoalJaquelineApplicationTests {

	@Test
	void contextLoads() {
	}

}
