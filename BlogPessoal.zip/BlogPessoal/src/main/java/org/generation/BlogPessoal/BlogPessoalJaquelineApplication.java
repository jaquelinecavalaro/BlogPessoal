package org.generation.BlogPessoal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlogPessoalJaquelineApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlogPessoalJaquelineApplication.class, args);
	}

}
